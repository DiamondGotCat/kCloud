# home/models.py
from django.db import models

# モデルは特に定義されていませんが、必要に応じて追加できます。
