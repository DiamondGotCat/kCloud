# message/models.py
from django.db import models

# メッセージのモデルが必要な場合は、ここに追加できます。
