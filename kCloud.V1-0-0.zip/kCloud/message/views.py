# message/views.py
from django.shortcuts import render

def message(request):
    return render(request, 'message/index.html')
