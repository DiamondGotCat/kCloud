# kCloud/urls.py
from django.contrib import admin
from django.urls import path, include  # includeを追加

urlpatterns = [
    path('', include('home.urls')),
    path('admin/', admin.site.urls),
    path('drive/', include('drive.urls')),  # driveアプリケーション用のURLを追加
]
