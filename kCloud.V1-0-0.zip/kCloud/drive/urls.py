# drive/urls.py
from django.urls import path
from . import views

urlpatterns = [
    path('', views.drive, name='drive'),
    path('download/<str:filename>/', views.download_file, name='download_file'),
    path('delete/<str:filename>/', views.delete_file, name='delete_file'),
    path('edit/<str:filename>/', views.edit_file, name='edit_file'),
    path('create/<str:filename>/', views.create_file, name='create_file'),
]
