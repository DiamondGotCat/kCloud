# drive/models.py
from django.db import models

# ファイルのモデルが必要な場合は、ここに追加できます。
