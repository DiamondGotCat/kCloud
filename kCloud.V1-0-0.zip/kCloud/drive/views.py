# drive/views.py
from django.shortcuts import render, redirect
from django.http import HttpResponse
import os

def drive(request):
    # ファイル一覧を取得する
    file_list = os.listdir('files/')  # ファイルが格納されているディレクトリを指定

    return render(request, 'drive/index.html', {'file_list': file_list})

def create_file(request, filename=None):  # filenameを引数として受け取るように修正
    if request.method == 'POST':
        file_content = request.POST.get('fileContent')

        # ファイルの作成
        if filename:
            file_path = os.path.join('files/', filename)
            with open(file_path, 'w') as f:
                f.write(file_content)

            return HttpResponse('File created successfully')

    return HttpResponse('Invalid request method or filename')

# ダウンロード処理
def download_file(request, filename):
    file_path = os.path.join('files/', filename)
    if os.path.exists(file_path):
        with open(file_path, 'rb') as f:
            response = HttpResponse(f.read(), content_type="application/octet-stream")
            response['Content-Disposition'] = f'attachment; filename="{filename}"'
            return response
    else:
        return HttpResponse("File not found")

# ファイル削除処理
def delete_file(request, filename):
    if request.method == 'POST':
        file_path = os.path.join('files/', filename)
        try:
            os.remove(file_path)
            return HttpResponse('File deleted successfully')
        except FileNotFoundError:
            return HttpResponse('File not found')
    
    return HttpResponse('Invalid request method')

# ファイル編集処理
def edit_file(request, filename):
    if request.method == 'GET':
        file_path = os.path.join('files/', filename)
        with open(file_path, 'r') as f:
            file_content = f.read()

        return render(request, 'drive/edit_file.html', {'filename': filename, 'file_content': file_content})
    elif request.method == 'POST':
        file_content = request.POST.get('fileContent')

        # ファイルの保存
        file_path = os.path.join('files/', filename)
        with open(file_path, 'w') as f:
            f.write(file_content)

        return redirect('drive')  # ファイル保存後にドライブ画面にリダイレクトする
